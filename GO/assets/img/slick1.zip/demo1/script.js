$(document).ready(function(){
    $('.slider').slick({
      // dots: true,
      autoplay: true,
      autoplaySpeed: 2500,
      
      // slidesToShow: 1,
      // slidesToScroll: 1,
    });
  });